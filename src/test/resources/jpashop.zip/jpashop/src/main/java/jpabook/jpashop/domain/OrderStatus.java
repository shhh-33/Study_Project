package jpabook.jpashop.domain;

//enum : 열거형 타입 : 관련있는 문자열이나 숫자등 기본 자료형의 값을 고정 (final같은..)
public enum OrderStatus {
    ORDER,CANCEL
}
